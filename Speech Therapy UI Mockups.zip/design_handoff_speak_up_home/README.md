# Handoff: Speak Up — bilingual home page (Astro target)

## Overview
Marketing home page for **Speak Up**, a speech & language therapy clinic in Tirana, Albania.
Audience: parents of children aged ~2–12 (plus adult clients). The page must read **child-friendly but
professionally credible** — playful mascot and toy-like interaction up top, calm factual pricing/licence
information near the bottom.

Hard requirement: a **language switch in the top-right header** toggling Albanian (default) and English.
Every string on the page swaps, including alt/aria text, price formats (`4.500 Lek` vs `4,500 Lek`),
date labels (`14 sht.` vs `14 Sep`) and time formats (`16:00` vs `4:00 pm`).

## About the design files
`Speak Up Home v4.dc.html` in this folder is a **design reference created in HTML**, not production code.
It is a prototype of the intended look and behaviour. Do not port it verbatim.

**Target: Astro.** Recreate the design as an Astro site using Astro's own conventions:
- `src/layouts/Base.astro` for `<head>`, fonts, global resets.
- `src/components/*.astro` for each section (Header, Hero, SoundOfTheWeek, WhatWeDo, StarChart, Room, ParentFacts, Cta, Footer).
- Copy lives in `src/i18n/sq.json` and `src/i18n/en.json`; do not hardcode strings in components.
- Routing: `src/pages/index.astro` (Albanian, default, served at `/`) and `src/pages/en/index.astro`.
  Use Astro i18n routing with `defaultLocale: "sq"`, `locales: ["sq","en"]`, `prefixDefaultLocale: false`.
  The header switch is then a plain `<a>` to the mirrored URL — **no client-side JS needed for language**,
  which is better than the prototype (it uses component state because it's a single-file mock).
- Styling: the prototype uses inline styles only because of its authoring constraints. In Astro use
  **scoped `<style>` blocks per component** plus a small global token file. Do not replicate inline styles.
- The only island that needs JS is the "Sound of the week" picker — one small client component
  (`client:visible`), or ~15 lines of vanilla JS in the component's own `<script>`.

## Fidelity
**High-fidelity.** Colours, type scale, radii, shadows, copy and animation timings below are final —
match them. Layout proportions are intentional; the grid column ratios matter.

---

## Design tokens

### Colour
| Token | Hex | Use |
|---|---|---|
| `--gold` | `#F0B01F` | Primary accent: mascot front bubble, highlight pill, CTA band, active states, sound bubble |
| `--deep` | `#4A3B22` | Mascot back bubble, dark buttons, star-chart panel, footer |
| `--ink` | `#3B2F1C` | Body text, headings |
| `--muted` | `#6F6249` | Secondary text, lede paragraphs, nav links |
| `--paper` | `#FFF8E8` | Page background |
| `--card` | `#FFFDF5` | Cards, pills, parents strip background |
| `--sky` | `#8FB9C9` | Card 1 tint, "Rrr!" sticker |
| `--mint` | `#9DC08B` | Card 2 tint, "Bravo!" sticker |
| `--coral` | `#E58F6F` | Card 3 tint, "one more time" sticker |
| eyebrow gold | `#A9700B` | Small uppercase eyebrow labels, links |

Derived values used verbatim in the mock:
- hairlines / card borders: `rgba(59,47,28,.10)` – `rgba(59,47,28,.14)`, width `1.5px`
- "pressed" card shadow: `0 5px 0 rgba(59,47,28,.07)`
- button pressed shadow: `0 4px 0 rgba(59,47,28,.28)` (dark), `0 3px 0 rgba(59,47,28,.22)` (gold header CTA)
- mascot lift: `0 20px 40px -24px rgba(59,47,28,.55)`, plus inner `inset 0 -12px 0 rgba(59,47,28,.09)`
- page texture: `radial-gradient(rgba(59,47,28,.045) 1px, transparent 1px)` at `background-size: 22px 22px`

### Type
- Display / headings / numbers: **Fredoka** (Google Fonts), weights 400–700, `letter-spacing:-.015em`, `line-height:1.06–1.15`
- Body / UI: **Nunito Sans** (Google Fonts, variable `opsz 6..12`), weights 400/600/700
- Scale (all `clamp()`, fluid):
  - h1 `clamp(40px, 5.4vw, 68px)` / lh 1.04 / max-width 15ch
  - h2 `clamp(30px, 3.5vw, 44px)` / lh 1.06 / max-width 15ch
  - h2 on dark `clamp(28px, 3.2vw, 40px)` / max-width 13ch
  - h3 (cards) `21px` / lh 1.15
  - hero paragraph `16.5px` / lh 1.68 / max-width 48ch
  - lede `15.5px` / lh 1.70
  - body in cards `14.5px` / lh 1.64
  - eyebrow `11.5px`, weight 700, `letter-spacing:.15em`, uppercase
  - fact value `24px` Fredoka; toy word `clamp(30px,3.8vw,46px)` Fredoka
  - spell-out label `14.5px`, weight 700, `letter-spacing:.18em`, uppercase, `rgba(59,47,28,.55)`

### Radius
`999px` pills/buttons · `34px` star-chart panel · `32px` CTA box · `30px` toy box · `28px` cards ·
`26px` room photo · `22px` fact cells · `20px` card art · `18px` sound buttons ·
toy bubble `44px 44px 12px 44px` (tail bottom-left) ·
speech-bubble shape `50% 50% 50% 10% / 50% 50% 50% 32%`

### Layout
- Container: `max-width:1140px`, side padding `clamp(20px,4vw,44px)`, centred
- Section rhythm: `padding-top: clamp(44px,5.5vw,76px)`, `padding-bottom: clamp(8px,1.5vw,16px)`
- Grid gaps: `clamp(14px,2vw,20px)` cards · `clamp(22px,4vw,48px)` two-column splits

---

## Screens / sections (top to bottom)

### 1. Header — sticky
Sticky, `z-index:30`, `background: rgba(255,248,232,.93)` + `backdrop-filter: blur(8px)`,
`border-bottom: 1px solid rgba(59,47,28,.1)`, padding `13px 0`.
Three flex groups: brand (`flex:none`) · nav (`flex:1 1 auto; min-width:0; overflow-x:auto`, scrollbar hidden,
`flex-wrap:nowrap`) · controls (`flex:none`).

- **Brand**: 36×26 SVG logo mark (two speech bubbles: back `#4A3B22`, front `--gold`) + wordmark
  "Speak Up" in Fredoka 700 / 22px, `white-space:nowrap` (must never wrap).
- **Nav** (SQ → EN): Tingulli i javës → Sound of the week `#toy` · Çfarë bëjmë → What we do `#what` ·
  Dhoma → The room `#what` · Për prindërit → For parents `#parents`.
  `font-size: clamp(12.5px,1.3vw,14px)`, weight 600, colour `--muted`.
- **Language switch (top right, required)**: two buttons in a `rgba(59,47,28,.07)` pill track, 3px padding.
  Active = `--deep` fill, `#FFF8E8` text, weight 700, 12.5px, radius 999px. Inactive = transparent,
  `rgba(59,47,28,.5)`. Labels `SQ` / `EN`.
  **In Astro:** render as two `<a>` links to `/` and `/en/`, with `aria-current="true"` on the active one,
  and `hreflang` set. Keep the visual treatment identical.
- **CTA button**: gold, radius 999px, padding `10px 18px`, 13.5px/700, shadow `0 3px 0 rgba(59,47,28,.22)`.
  Copy: `Rezervo` / `Book`.

### 2. Hero
Grid `minmax(0,1.05fr) minmax(0,.95fr)`, gap `clamp(24px,4vw,52px)`, `align-items:center`,
`padding: clamp(34px,5vw,60px) 0 clamp(30px,4vw,52px)`, `overflow:hidden`.

**Left column**
- Pill: `Logopedi për fëmijë · Tiranë` / `Children's speech therapy · Tirana` — `--card` bg,
  `1.5px solid rgba(59,47,28,.14)`, radius 999px, padding `8px 15px`, 12.5px/700, `--muted`.
- **H1 with an inline highlight pill** (the client specifically approved this treatment):
  - SQ: `Këtu fjalët ` + **`dalin`** + ` duke luajtur`
  - EN: `Here words come out while ` + **`playing`**
  - The highlighted word is `display:inline-block; margin:0 2px; padding:2px 14px; border-radius:999px;
    background:var(--gold); color:var(--ink); transform:rotate(-1.5deg); line-height:1.12`.
  - **i18n note:** the highlight word is a separate JSON key (`h1a`, `h1word`, `h1b`) so each language can
    put the pill on a grammatically sensible word. `h1b` may be an empty string.
- Paragraph, then two buttons: dark pill primary (`Rezervo vlerësimin` / `Book an assessment`) and
  `--card` outlined secondary (`Si duket një seancë` / `What a session looks like`), both radius 999px,
  padding `16px 26px`, 15.5px/700.
- **Trust chips** row (8px gap, 26px above): `Terapiste e licencuar`, `Prindi rri në dhomë`,
  `Raport me shkrim` / `Licensed therapist`, `Parent stays in the room`, `Written report`.
  Backgrounds in order: `rgba(143,185,201,.22)`, `rgba(157,192,139,.24)`, `rgba(229,143,111,.2)`.

**Right column — mascot (build from the logo mark, do not use an illustration)**
- Wrapper: `position:relative; display:grid; place-items:center; min-height:clamp(280px,32vw,400px)`.
- Mascot container: `width:clamp(230px,27vw,320px); aspect-ratio:1/.92`, animation `float 6s ease-in-out infinite`.
- Back bubble: absolute `left:0; top:0; width:74%; aspect-ratio:1/.86`,
  `border-radius:50% 50% 50% 10%/50% 50% 50% 32%`, fill `--deep`.
- Front bubble: absolute `right:0; bottom:0; width:80%; aspect-ratio:1/.86`, same radius, fill `--gold`,
  inner + drop shadow as listed in tokens; flex column centre, gap `clamp(12px,1.7vw,18px)`, `padding-bottom:6%`.
  Contains the face.
- Face: two eyes in a row, gap `clamp(24px,3.2vw,42px)`, each
  `width:clamp(13px,1.5vw,18px); height:clamp(19px,2.2vw,26px); border-radius:50%; background:var(--deep)`,
  animation `blink 5.5s infinite`. Mouth: `width:clamp(40px,5vw,60px); height:clamp(22px,2.8vw,33px);
  border-radius:0 0 999px 999px; background:var(--deep)`.
- Ground shadow: absolute `bottom:-4%; right:6%; width:clamp(140px,16vw,200px); height:20px;
  border-radius:50%; background:rgba(59,47,28,.1); filter:blur(3px)`.
- Three floating stickers, each `position:absolute`, rotated, radius `999px 999px 999px 6px`
  (or mirrored for the mint one), shadow `0 6px 0 rgba(59,47,28,.15)`, Fredoka 600 / 14–15px,
  animation `float` at 5s / 6.4s (delay .6s) / 7s (delay .3s):
  - `Rrr!` — top 6%, left 2%, `-8deg`, `--sky` on `#1F3742`
  - `Bravo!` / `Well done!` — bottom 14%, left −2%, `6deg`, `--mint` on `#2A3A21`
  - `Edhe një herë` / `One more time` — top 16%, right −1%, `9deg`, `--coral` on `#40190C`

### 3. Sound of the week — the one interactive island
Head: eyebrow `Provoje tani` / `Try it now`, h2 `Tingulli i javës` / `Sound of the week`, lede right-aligned column.

Box: grid `minmax(0,88px) minmax(0,1fr)`, gap `clamp(16px,2.6vw,28px)`, padding `clamp(18px,2.6vw,28px)`,
radius 30px, `--card` bg, `1.5px` border, pressed shadow.

- **Left rail**: five buttons stacked, 10px gap — `R`, `S`, `SH`, `L`, `K`. Fredoka 22px, radius 18px,
  padding `14px 0`. Inactive `rgba(59,47,28,.05)` with transparent border. Active `--gold`,
  `1.5px solid rgba(59,47,28,.2)`, shadow `0 4px 0 rgba(59,47,28,.2)`. Transition `background .16s ease`.
- **Stage**: grid `minmax(0,1fr) minmax(0,1.05fr)`, gap `clamp(16px,2.4vw,26px)`.
  - Gold bubble (radius `44px 44px 12px 44px`, min-height 190px, centred) holding the word
    (Fredoka `clamp(30px,3.8vw,46px)`) and the spelled-out form below.
    Re-runs `pop .26s ease` on every change of selection.
  - Tip column: eyebrow `Këshilla për në shtëpi` / `Tip for home`, tip paragraph 16px/1.66 max 46ch,
    then an age chip (`rgba(59,47,28,.07)`, radius 999px, 12.5px/600).

Content (SQ word / spelling / tip / age — EN adds a gloss in brackets after the word):
| Sound | Word | Spelled | Typical age |
|---|---|---|---|
| R | rrota (wheel) | r-r-ro-ta | ~5–6 |
| S | sytë (eyes) | s-y-të | ~4–5 |
| SH | shishe (bottle) | sh-i-she | ~4–5 |
| L | lule (flower) | l-u-le | ~3–4 |
| K | kalë (horse) | k-a-lë | ~3–4 |
Tips are full sentences of real articulation guidance — copy them verbatim from the two dictionaries at the
top of the reference file (`SQ.sounds` / `EN.sounds`, index 3 of each row).

State: one integer `selectedSound` (default `0`). No URL state, no persistence.

### 4. What we do — three cards
Grid `repeat(3, minmax(0,1fr))`, gap `clamp(14px,2vw,20px)`.
Each card: `--card`, radius 28px, `1.5px` border, pressed shadow, padding `clamp(20px,2.6vw,26px)`,
`position:relative`.
- Number badge: absolute `top:-13px; left:22px`, 34×34 circle, tint colour per card index
  (sky / mint / coral), `2px solid var(--card)`, Fredoka 16px.
- Art panel: height 104px, radius 20px, background = tint at ~18% opacity (`<tint>2E`), centring a
  72×66 organic blob (`border-radius:52% 48% 44% 56%/56% 50% 50% 44%`) in the solid tint.
  *These blobs are placeholders for real photography or spot illustration — flag to the client.*
- Then h3 + body copy. Titles: Lojëra me tinguj / Pasqyra e madhe / Detyra e vogël e shtëpisë.

### 5. Star chart — dark panel
Box: grid `minmax(0,.92fr) minmax(0,1.08fr)`, gap `clamp(22px,4vw,48px)`, padding `clamp(24px,3.4vw,40px)`,
radius 34px, background `--deep`.
Left: gold eyebrow, cream h2 `Tabela e yjeve` / `The star chart`, paragraph `rgba(255,248,232,.72)`.
Right: `repeat(5, minmax(0,1fr))` grid of 10 circles, gap `clamp(8px,1.4vw,14px)`, `aspect-ratio:1`.
First 6 = earned: `--gold` fill, `--deep` ★ glyph at `clamp(18px,2.2vw,26px)`, and
`animation: pop .34s ease both` with a **0.09s stagger per index** (0s, .09s, .18s…).
Remaining 4 = empty: `rgba(255,248,232,.08)` fill, `2px dashed rgba(255,248,232,.28)`.

### 6. The room
Grid `minmax(0,1.05fr) minmax(0,.95fr)`, gap `clamp(22px,4vw,48px)`, centred.
Left: **real photo required**, `aspect-ratio:4/3`, radius 26px, pressed shadow. In the prototype this is a
drag-and-drop placeholder (`image-slot.js`) — in Astro use `astro:assets` `<Image>` with the client's photo.
Right: eyebrow `Dhoma` / `The room`, h2, then four bullet rows — 11px gold dot (`margin-top:7px`) + 15.5px/1.62 text.

### 7. For parents — the credibility strip
Full-bleed band: `--card` background, `1.5px` top and bottom borders, padding `clamp(40px,5vw,64px) 0`.
Grid `repeat(4, minmax(0,1fr))`, gap `clamp(12px,2vw,18px)`. Each cell: `--paper` bg, radius 22px,
`1.5px` border, padding 20px, containing uppercase key (11px/700/.13em), Fredoka 24px value, 13px note.

| Key | Value | Note |
|---|---|---|
| Vlerësimi i parë / First assessment | 4.500 Lek / 4,500 Lek | 60 min, written report within 3 days |
| Seanca / Session | 3.500 Lek / 3,500 Lek | 45 min · pack of 8: 24.000 Lek |
| Radha / Waiting list | rreth 2 javë / about 2 weeks | Free cancellation up to 24h before |
| Licenca / Licence | Nr. 4821 | Order of Health Professionals · MSc SLT, UT |

**All four values are placeholders supplied for layout.** The client must confirm real prices, the real
waiting time and the real licence number before launch — flag this explicitly in the repo.

### 8. CTA band + footer
CTA: flex-wrap row, gap `clamp(16px,3vw,32px)`, padding `clamp(22px,3vw,32px)`, radius 32px, `--gold` bg,
shadow `0 6px 0 rgba(59,47,28,.14)`. Contains a 70×64 mini bubble (deep fill, two gold eyes 9×13),
heading + paragraph, then the dark CTA button and the phone number in Fredoka 19px.
Footer: `--deep` bg, `rgba(255,248,232,.6)` text, 12.5px, two ends — copyright/address left, hours right.

---

## Interactions & behaviour
| Name | Spec |
|---|---|
| `float` | `translateY(0 → -10px → 0)`, 5–7s, `ease-in-out`, infinite. Applied to the mascot and each sticker at different durations/delays so they never sync. Stickers preserve their rotation via a `--r` custom property. |
| `blink` | `scaleY(1)` held to 92%, `scaleY(.1)` at 96%, back to 1. 5.5s infinite. Both eyes together. |
| `pop` | `opacity 0 → 1`, `scale(.86) → scale(1)`, `.26s` (toy bubble) / `.34s` (stars) `ease both`. |
| Sound picker | Click a letter → swap word/spelling/tip/age and replay `pop` on the bubble. Keyboard accessible; use real `<button>`s with `aria-pressed`. |
| Language switch | In Astro: navigation between `/` and `/en/`. Preserve the hash fragment if present. |
| Hover | Cards and buttons lift subtly; keep it under 150ms. Nav links darken to `--ink`. |
| Reduced motion | **Not handled in the prototype — add it.** Wrap `float`/`blink`/`pop` in `@media (prefers-reduced-motion: no-preference)`. |

## Responsive
The prototype is desktop-first with fluid `clamp()` sizing and was not built below ~900px. You need to add:
- ≤900px: hero → single column, mascot above or below text; toy stage → stacked; 3-card grid → 1 column;
  star chart → stacked, star grid stays 5 across; parents strip → 2×2.
- ≤560px: nav collapses (the prototype's horizontal scroll is a stopgap — a proper disclosure menu is better);
  keep the language switch and phone number always visible.
- Minimum tap target 44px throughout — the sound buttons and language switch are the ones to watch.

## Accessibility notes for the rebuild
- The mascot is decorative: `aria-hidden="true"` on the whole assembly.
- Star chart needs a text equivalent, e.g. `<p class="sr-only">6 of 10 stars collected</p>`.
- Language links need `lang` + `hreflang` attributes; set `<html lang>` per route.
- Check gold `#F0B01F` text combinations: gold on cream fails contrast for body copy — it is only used as a
  **background** behind `--ink` in this design. Keep it that way.
- The eyebrow gold `#A9700B` on `--paper` passes for small text; don't lighten it.

## Assets
- **Logo**: the client's two-bubble mark. Reproduced in the prototype as inline SVG paths (see the header
  and footer of the reference file) — reuse those paths, or better, ask the client for the original vector.
- **Fonts**: Fredoka + Nunito Sans, Google Fonts. In Astro prefer self-hosting via `@fontsource/fredoka`
  and `@fontsource-variable/nunito-sans` to drop the third-party request.
- **Photography**: none supplied yet. Needed for the room section and, ideally, to replace the three card
  blobs. Placeholders in the prototype are drop zones from `image-slot.js` (included here for reference
  only — do not port it).

## Files in this bundle
- `Speak Up Home v4.dc.html` — the design reference. Open it in a browser; the language switch and the
  sound picker both work. All copy for both languages lives in the `SQ` and `EN` objects at the top of its
  script block — **use these as the source for the i18n JSON files**.
- `image-slot.js` — supports the photo drop zones in the reference file. Reference only.

## Suggested Astro project shape
```
src/
  layouts/Base.astro
  components/{Header,Hero,Mascot,SoundOfTheWeek,WhatWeDo,StarChart,Room,ParentFacts,Cta,Footer}.astro
  components/SoundPicker.astro      # the only component with a <script>
  i18n/{sq.json,en.json}
  i18n/utils.ts                     # t() helper + locale from Astro.currentLocale
  styles/tokens.css                 # the colour/radius/shadow tokens above
  pages/index.astro                 # sq
  pages/en/index.astro              # en
astro.config.mjs                    # i18n: defaultLocale 'sq', prefixDefaultLocale: false
```
No framework integration is required — Astro + one inline script covers everything on this page.
